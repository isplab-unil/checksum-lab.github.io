<?php
/**
 * @package Link Integrity
 * @version 0.1
 */
/*
Plugin Name: Link Integrity
Description: The plugin automatically adds an integrity attribute to HTML links.
Author: Anonymous
Version: 0.1
*/

$linkintegrity_version = '0.1';

function linkintegrity($post_id) {
	// wordpress database
	global $wpdb;

	// retrieve the content
	$content = get_post($post_id)->post_content;

	// parse the post and search for links
	preg_match_all('|<a.*(?=href=\"([^\"]*)\")[^>]*>([^<]*)</a>|i', $content, $match);
	
	// iterate over the links
    foreach($match[1] as $link) {
		// retrieve the link from the database
		$existing_link = $wpdb->get_results("SELECT link, hash FROM ".$wpdb->prefix."linkintegrity WHERE link = '$link'");

		if (count($existing_link) > 0) {
			// retrieve hash from database
			$hash = $existing_link[0]->hash;

			// add the integrity attribute
			$content = str_replace('href="'.$link.'"', 'href="'.$link.'" integrity="sha256-'.$hash.'"', $content);
		
		} else {
			// perform a HEAD request
			$head = curl_init();
			curl_setopt($head, CURLOPT_URL, $link);
			curl_setopt($head, CURLOPT_HEADER, true);
			curl_setopt($head, CURLOPT_NOBODY, true);
			curl_setopt($head, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($head, CURLOPT_BINARYTRANSFER, true);
			curl_setopt($head, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($head, CURLOPT_VERBOSE, false);
			
			$headers = curl_exec($head);
			curl_close($head);

			// is this file downloadable?
			if (strpos($headers, 'application/octet-stream') !== false 
					|| strpos($headers, 'application/x-msdos-program') !== false 
					|| strpos($headers, 'application/x-apple-diskimage') !== false 
					|| strpos($headers, 'application/x-msdownload') !== false) {

				// perform a GET request
				$get = curl_init();
				curl_setopt($get, CURLOPT_URL, $link);
				curl_setopt($get, CURLOPT_HEADER, false);
				curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($get, CURLOPT_BINARYTRANSFER, true);
				curl_setopt($get, CURLOPT_FOLLOWLOCATION, true);
				curl_setopt($get, CURLOPT_VERBOSE, false);
				$body = curl_exec($get);
				curl_close($get);

				// compute the hash
				$hash = hash('sha256', $body);

				$wpdb->insert( 
					$wpdb->prefix."linkintegrity",
					array('link' => $link, 'hash' => $hash)
				);
			}

			// add the integrity attribute
			$content = str_replace('href="'.$link.'"', 'href="'.$link.'" integrity="sha256-'.$hash.'"', $content);
		}
	}
	
    // unhook the function so it doesn't loop infinitely
    remove_action('save_post', 'linkintegrity');
	
	// update the post
	$new_post = array('ID' => $post_id, 'post_content' => $content);
    wp_update_post($new_post, true);
	
	// rehook the function
    add_action('save_post', 'linkintegrity');
}

function linkintegrity_activate($post_id) {
	// wordpress database
	global $wpdb;

	// create sql query
	$table_name = $wpdb->prefix.'linkintegrity';
	$charset_collate = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE $table_name (
		id int NOT NULL AUTO_INCREMENT,
		link text NOT NULL,
		hash text NOT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";

	// execute sql query
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql);
	add_option('linkintegrity_version', $linkintegrity_version);
}

add_action('save_post', 'linkintegrity', 10);
register_activation_hook( __FILE__, 'linkintegrity_activate');