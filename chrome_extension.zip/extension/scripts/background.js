CHECKSUM_TYPE_MD5 = 'md5';
CHECKSUM_TYPE_SHA1 = 'sha1';
CHECKSUM_TYPE_SHA256 = 'sha256';
CHECKSUM_TYPE_PGP = 'pgp';

function hash(algo, buffer) {
  return crypto.subtle.digest(algo, buffer).then(function (hash) {return Array.from(new Uint8Array(hash)).map(b => ('00' + b.toString(16)).slice(-2)).join('');});
}

function base64Encode(array) {
  return btoa(String.fromCharCode.apply(null, array));
}

function base64Decode(string) {
  return new Uint8Array(atob(string).split("").map(function(c) { 
      return c.charCodeAt(0); 
  }));
}

function send_error(tab, message) {
  chrome.tabs.sendMessage(tab, {
    type: "error",
    message: message
  });
}

// Configure the public key server
var hkp = new openpgp.HKP('https://pgp.mit.edu');

// Keep track of the download requests
var downloads = {};

// Intercept the download requests emitted by tabs
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  var tab = parseInt(sender.tab.id);

  switch(request.type) {
    case "download":
      chrome.downloads.download({url: request.download}, function(downloadId) {
        downloads[downloadId] = {
          request: request,
          download: request.download,
          checksum: request.checksum,
          tab: tab
        }
      });
      chrome.tabs.sendMessage(tab, {
        type: "downloading",
        checksum_origin: request.checksum.origin
      });
      break;
    case "remove":
      chrome.downloads.removeFile(request.id);
      break;
    default:
      send_error(tab, "Unknown request type: " + request.type);
      break;
  }
});

chrome.downloads.onChanged.addListener(function(download) {

  if(!(download.id in downloads)) { // the download was not registered (i.e., wasn't triggered from a download link instrumented by the ext)
    return;
  }

  var tab = downloads[download.id].tab;
  // Register the local filename of the download
  if (download.filename) {
    downloads[download.id].filename = "file://" + download.filename.current;
  }

  // Compute the checksum of the downloaded file
  if (download.state && download.state.current == 'complete') {
    var xhr = new XMLHttpRequest();
    xhr.responseType = 'arraybuffer';
    
    // Send the a verification message to the tab that created the download request
    xhr.addEventListener("load", function() {

      chrome.tabs.sendMessage(tab, {type: "computing"});

      var checksum = downloads[download.id].checksum;
      var checksum_value_computed;
      var checksum_types = checksum.type;
      var checksum_value_actual = new Set(checksum.value);
      var checksum_value_computed = new Set();

      for(var checksum_type of checksum_types) {
        switch(checksum_type) {
          case CHECKSUM_TYPE_MD5:
            checksum_value_computed.add(md5.hex(xhr.response));
            break;
          case CHECKSUM_TYPE_SHA1:
            checksum_value_computed.add(asmCrypto.SHA1.hex(xhr.response));
            break;
          case CHECKSUM_TYPE_SHA256:
            checksum_value_computed.add(asmCrypto.SHA256.hex(xhr.response));
            break;
          case CHECKSUM_TYPE_PGP:
            var checksum_keyId = checksum.keyId;
            var checksum_fingerprint = checksum.fingerprint;
            hkp.lookup({
              keyId: checksum_keyId
            }).then(function(response) {
              var publicKeys = openpgp.key.readArmored(response).keys;
              if (publicKeys[0].primaryKey.fingerprint == checksum_fingerprint) {
                var options = {
                  publicKeys: publicKeys,
                  signature: openpgp.signature.read(base64Decode(checksum.value)),
                  message: openpgp.message.fromBinary(new Uint8Array(xhr.response))
                };
                openpgp.verify(options).then(function(verified) {
                  validity = verified.signatures[0].valid;
                  // If the verification succeed, we can safely assume that the computed checksum
                  // corresponds to the actual checksum
                  if (validity) {
                    checksum_value_computed = checksum_value_actual;
                  } 
                  chrome.tabs.sendMessage(tab, {
                    type: "verifying",
                    valid: new Set([...checksum_value_computed].filter(x => checksum_value_actual.has(x))).size > 0,
                    checksum_value_actual: [...checksum_value_actual],
                    checksum_value_computed: [...checksum_value_computed],
                    checksum_origin: checksum.origin,
                    id: download.id,
                  });
                  delete downloads[download.id];
                });
              } else {
                send_error(tab, "An error occured while computing the checksum: The PGP fingerprint does not match.");
              }
            }).catch(function(error) {
              send_error(tab, "A problem occured while computing the checksum: PGP server unreachable.");
            });
            return;
          default:
            send_error(tab, "An error occured while computing the checksum: Unknown checksum type '" + checksum_type + "'");
            continue;
        }
      }
      chrome.tabs.sendMessage(tab, {
        type: "verifying",
        valid: new Set([...checksum_value_computed].filter(x => checksum_value_actual.has(x))).size > 0,
        checksum_value_actual: [...checksum_value_actual],
        checksum_value_computed: [...checksum_value_computed],
        checksum_origin: checksum.origin,
        id: download.id,
      });
      delete downloads[download.id];
    });

    // Send an error message to the tab that created the download request
    xhr.addEventListener("error", function() {
      send_error(tab, "An error occured while accessing the downloaded file");
      delete downloads[download.id];
    });

    // Send the request to read the local (downloaded file)
    xhr.open("GET", downloads[download.id].filename, true);
    xhr.send();
  }
  
});
